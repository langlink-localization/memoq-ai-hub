# @langlink-tech/antd-kit

LangLink shared Ant Design patterns. Shared patterns for tables, dashboards, forms, navigation, analysis, state surfaces, overlay shells and a contrast-floor theme.

The source repository is public so host CI can install a pinned git SHA without a
cross-repo token. GitHub Packages remains restricted (`publishConfig.access:
restricted`); switching consumers to the registry still needs `packages` scope
and Actions package access.

## Install

GitHub Packages, restricted:

```ini
@langlink-tech:registry=https://npm.pkg.github.com
```

```sh
pnpm add @langlink-tech/antd-kit@0.6.2
```

Actions consumers need `packages: read` and `NODE_AUTH_TOKEN` from the runtime. Do not assume same-organization packages are readable without that permission.

## Motion

```ts
import {
  ReducedMotionProvider,
  usePrefersReducedMotion,
  useReducedMotion,
} from "@langlink-tech/antd-kit/motion";

const reduceMotion = usePrefersReducedMotion();

<ReducedMotionProvider reduceMotion={reduceMotion}>
  {children}
</ReducedMotionProvider>
```

SSR initial value is `true`. The system hook listens to `prefers-reduced-motion` and cleans up. Hosts that need an override pass `reduceMotion` into `ReducedMotionProvider`.

Adaptive display preferences (contract AD-01) use the same subscription model:

| Hook | Media query | SSR / no `matchMedia` |
| --- | --- | --- |
| `usePrefersReducedTransparency` | `(prefers-reduced-transparency: reduce)` | `true` (solid surfaces) |
| `usePrefersContrastMore` | `(prefers-contrast: more)` | `false` |
| `usePrefersForcedColors` | `(forced-colors: active)` | `false` |
| `useSystemDisplayPreferences` | all four | per hook |

Plain CSS media queries remain the first choice for static surfaces; use the hooks when a theme or
canvas value must change at runtime. The kit ships no preference provider; hosts own mapping into
`ConfigProvider` or CSS.

### Contrast-more theme (0.6.2)

`prefers-contrast: more` needs real borders on functional surfaces (contract AD-01). Wrap the host's
whole theme config at the root provider; the kit still ships no provider:

```tsx
import { usePrefersContrastMore, withContrastMoreTheme } from "@langlink-tech/antd-kit/motion";

const contrastMore = usePrefersContrastMore();
const adaptiveTheme = useMemo(() => withContrastMoreTheme(theme, contrastMore), [theme, contrastMore]);
<ConfigProvider theme={adaptiveTheme}>
```

With the preference on, the kit algorithm sets `colorBorder` to `colorTextSecondary` (at least 3:1
against both `colorBgContainer` and grey `colorBgLayout` surfaces, light and dark, WCAG 1.4.11) and
`colorBorderSecondary` to `colorTextTertiary` (at least 3:1 on containers); `colorSplit` follows.
0.6.1 used the tertiary colour for `colorBorder`, which a real-browser check measured at 2.67:1 on a
grey page surface. Because AntD applies `theme.token` and component tokens after algorithms,
`withContrastMoreTheme` also drops pinned `colorBorder` / `colorBorderSecondary` / `colorSplit`
(global and per component) so the algorithm wins. With the preference off it returns the same object.
`withContrastMore(algorithms, enabled)`, `useAdaptiveAlgorithm` and `contrastMoreAlgorithm` remain for
hosts that pin no border tokens; prefer `withContrastMoreTheme`.

### System display theme and stylesheet (0.7.0)

Hosts adopt all of AD-01 with one theme hook and one style element at the root provider:

```tsx
import { SystemDisplayStyle, useSystemDisplayTheme } from "@langlink-tech/antd-kit/motion";

<ConfigProvider theme={useSystemDisplayTheme(theme)}>
  <SystemDisplayStyle />
  {children}
</ConfigProvider>
```

`useSystemDisplayTheme(config)` applies `withContrastMoreTheme` and then
`withReducedTransparencyTheme`, following both system preferences. Keep `config` stable (module
constant or `useMemo`). Under `prefers-reduced-transparency: reduce`:

- the Tooltip surface (`colorBgSpotlight`) is flattened to a solid colour;
- `colorBgBlur` takes `colorBgElevated`;
- the scrim (`colorBgMask`) keeps dimming but rises to at least 0.72 opacity.

Pinned values of those tokens are dropped so the algorithm wins. `withSystemDisplayTheme(config, { contrastMore, reduceTransparency })` is the pure form.

`<SystemDisplayStyle />` renders `systemDisplayCss(prefix)` for the surrounding ConfigProvider's
`prefixCls`. It covers what a theme cannot express:

- **Reduced transparency:** it removes the `mask={{ blur: true }}` backdrop blur on Modal, Drawer
  and Image preview.
- **Forced colours:** the user agent forces backgrounds to `Canvas` and removes box-shadow. A
  Chromium check of AntD 6.6.2 found these losses:
  - no visible selection on Radio, Radio.Button, Segmented, Menu, Tabs, Steps, Pagination, Tree,
    and Select, Dropdown and Cascader options, or on the selected date in DatePicker;
  - Switch, Slider and Progress disappearing;
  - Rate showing every star filled;
  - popups (Select, DatePicker, Dropdown, Tooltip, Modal, Message, Notification) losing their edge.

  The stylesheet restores these indicators with system colours (`Highlight`, `HighlightText`,
  `CanvasText`, `GrayText`) and gives overlays a `CanvasText` outline. `forced-color-adjust: none` is
  scoped to indicator elements and never applied globally. Focus rings already survive (AntD uses
  outline or border), so the stylesheet leaves them to the user agent.

`pnpm test:rendered` checks these rules in Chromium with forced colours and reduced transparency
emulated. It compares computed colours against the resolved system colours, and control cases
prove the defects without the stylesheet.

`/shell` is not shipped. Product copies stay local until a third repo has a stable matching API.

## Contrast floor theme (0.9)

AntD's default text tiers are below WCAG 2.2 AA (4.5:1) in several places: link text is 4.10:1 on
white and 3.55:1 on the dark container, `Typography` secondary text 3.36:1, a success `Tag` 2.21:1.
jsdom axe cannot run `color-contrast`, so these pass component tests and fail in a browser. Wrap the
host's whole theme config once, at the root provider and before any system-display wrapper:

```tsx
import { withContrastFloorTheme } from "@langlink-tech/antd-kit/theme";
import { useSystemDisplayTheme } from "@langlink-tech/antd-kit/motion";

const floorTheme = useMemo(() => withContrastFloorTheme(hostTheme), [hostTheme]);
<ConfigProvider theme={useSystemDisplayTheme(floorTheme)}>
```

It resolves the host theme (seed, light or dark, compact or not) and, for each text slot below
4.5:1, takes the first AntD step that passes on the container, layout and elevated surfaces; when no
step passes it moves the colour away from the surface until it does. Seeds, surfaces and borders are
untouched. Memoize the call: it resolves the design token.

| Slot | Token | Default seed, light | Default seed, dark |
| --- | --- | --- | --- |
| Link text | `colorLink` (algorithm) | `#1677ff` 4.10 → `#0958d9` 6.16 | `#1668dc` 3.55 → lifted |
| Description, placeholder | `colorTextDescription`, `colorTextPlaceholder` | 45% / 25% → 65% tier | 45% / 25% → 65% tier |
| Status text | `color*Text` (algorithm); `Form`, `Button` `colorError` | error 3.27, success 2.27, warning 1.90 → lifted | error 4.35 → lifted |
| Solid primary fill | `Button`, `Switch`, `FloatButton` `colorPrimary` | `#1677ff` 4.10 → `#0958d9` 6.16 | unchanged (5.19) |
| Switch off track (under `unCheckedChildren`) | `Switch` `colorTextQuaternary`, `colorTextTertiary` | 25% tier, 1.90 → darkened | resting unchanged; hover 4.06 → darkened |
| Tag text | `Tag` `color{Success,Error,Warning,Info}`, `{preset}7` | on each tag's own tint | on each tag's own tint |
| Brand text | `Menu` (selected, hover, open submenu title), `Tabs`, `Pagination` | `#0958d9` | lifted |
| Field labels, empty text | `Descriptions.labelColor`, `Table` string `emptyText` | description tier | description tier |

Tokens the host already sets win, globally and per component, so a registered value keeps working
and the host owns its proof. Visible changes to expect on adoption: placeholders and secondary text
are darker; on dark surfaces a solid danger button keeps a readable red as text and switches its
label to the dark tone, because no red passes both as text on the page and under a white label.

ProComponents draws the query-filter expand/collapse control in `colorPrimary` and has no token for
it. `QueryTable` (`/pro-table`) sets a `collapseRender` that uses the link text colour; a host that
uses `ProTable` directly passes `search={{ collapseRender: renderQueryFilterCollapse }}`. A host's own
`collapseRender` wins. The ProLayout menu needs nothing extra: with the floor applied it scans clean,
including an open group with a selected child (`tests/rendered/contrast-pro.spec.ts`).

Not covered, because AntD exposes no token: primary `outlined` / `dashed` / `text` buttons on dark
surfaces (3.55:1), and text at reduced opacity (a loading button). `contrastRatio` and
`ensureContrast` are exported for host tokens and tests. Proof: `tests/theme.test.ts` (WCAG formula
over the resolved tokens, four mode and density combinations, three extra seeds) and
`tests/rendered/contrast-floor.spec.ts` (axe `color-contrast` in Chromium, with a plain-AntD control).

## Governed component patterns (0.4)

The entries are additive patterns, not renamed upstream exports. Host
providers, data requests, validation, permissions, selection and routing remain
in the application. Import only the entry needed by a page. ProTable and S2 are
optional peers; importing the other entries does not load either engine.

| Entry | Exports | Official API / example reference |
| --- | --- | --- |
| `/table` | `DataTable` | [Table empty, loading and row selection](https://ant.design/components/table/) |
| `/pro-table` | `QueryTable` | [ProTable](https://procomponents.ant.design/components/table), Pro `list/table-list` |
| `/dashboard` | `MetricCard`, `DashboardPanel` | [Pro analysis dashboard](https://github.com/ant-design/ant-design-pro/tree/master/src/pages/dashboard/analysis) |
| `/form` | `FormDialog`, `FormErrorSummary`, `FormActions` | [Form in Modal, scroll to error](https://ant.design/components/form/) |
| `/navigation` | `NavigationMenu` | [Controlled Menu](https://ant.design/components/menu/), named navigation landmark |
| `/s2` | `AnalysisSheet` | [S2 pivot example](https://s2.antv.antgroup.com/examples/basic/pivot), render/destroy/resize lifecycle |
| `/feedback` | `EmptyState`, `ContentLoading`, `PageResult` | [Empty](https://ant.design/components/empty/), [Skeleton](https://ant.design/components/skeleton/), [Spin](https://ant.design/components/spin/), [Result](https://ant.design/components/result/) |
| `/overlay` | `FormDrawer`, `PreviewDialog`, `ConfirmAction`, `useAppConfirm` | [Form in Drawer](https://ant.design/components/form/), [Modal](https://ant.design/components/modal/), [Popconfirm](https://ant.design/components/popconfirm/), [App](https://ant.design/components/app/) |

Library entries are client modules. Packed `dist/*.js` files keep a `"use client"`
directive so a Next.js Server Component can import `EmptyState` without turning
the whole page into a client shell. Optional Pro/S2 peers stay out of core
entries.

### Wrapper value

| Export | Decision | Shared behavior | Native allowed |
| --- | --- | --- | --- |
| `EmptyState` | keep | required `description`, optional `action` | native Empty only when there is no next-action contract |
| `PageResult` | keep | page-level Result; `extra` stays host-owned | native Result or Alert for inline recovery |
| `ConfirmAction` | keep | in-place Popconfirm; shared inflight promise (success closes, async reject and sync throw stay open and clear pending) | `useAppConfirm()` for high-risk/irreversible |
| `MetricCard` | keep | Statistic in a Card plus optional `trend` | native `Statistic` when Card chrome is wrong |

Do not remove these exports in 0.4. Return the `onConfirm` promise so rejection
stays a rejection. `void onConfirm()` at a call site drops that signal.

#### Consumer props map (read-only; this PR does not edit hosts)

| Export | Host path | Props actually passed |
| --- | --- | --- |
| `EmptyState` | `ll-lqa-test/src/pages/admin/AdminTestsPage.tsx` | `description`, `action` (create button) |
| `EmptyState` | `ll-lqa-test/src/pages/admin/AdminPeoplePage.tsx` | `description` only on no-matches |
| `EmptyState` | `secure-files-cloudflare/src/frontend/App.tsx` | `description`; table `emptyText` slot |
| `EmptyState` | `langlink-tech-portal/frontend/src/pages/ToolsPage.tsx` | empty/filter empty copy |
| `PageResult` | `ll-lqa-test/src/pages/NotFoundPage.tsx` | `status="404"`, `title`, `subTitle`, `extra` (back button) |
| `PageResult` | `langlink-tech-portal/frontend/src/App.tsx` | `status="404"`, `title`, `subTitle`, `extra` |
| `PageResult` | `antd-pro-clone/src/pages/exception/404/index.tsx` | imported as `Result`; `status`, `title`, `subTitle`, `extra` |
| `ConfirmAction` | `ll-lqa-test/src/pages/admin/AdminTestsPage.tsx` | `title`, `description`, `okText`, `cancelText`, `okButtonProps.danger`, `onConfirm` |
| `ConfirmAction` | `secure-files-cloudflare/src/frontend/App.tsx` | `title` (JSX), `onConfirm` wrapping delete |
| `ConfirmAction` | `secure-files-cloudflare/src/frontend/operations/OperationsPanel.tsx` | `title`, `onConfirm` retry/replay |
| `MetricCard` | `ll-lqa-test/src/pages/admin/AdminDashboardPage.tsx` | `statistic={{ title, value }}` |
| `MetricCard` | `langlink-tech-portal/frontend/src/pages/HomePage.tsx` | `variant="borderless"`, `styles.body.padding: 0`, `statistic` |
| `MetricCard` | `antd-pro-clone/src/pages/dashboard/workplace/index.tsx` | same borderless/zero-padding Statistic chrome |
| `MetricCard` | `plunet-chrome-plugin/src/sidepanel/components/OrderHealthPanel.tsx` | borderless Statistic counts |

Hosts that pass `variant="borderless"` and zero padding are the documented
Statistic carve-out: they may keep MetricCard or switch to native Statistic
without a library removal.

```tsx
import { DataTable } from '@langlink-tech/antd-kit/table';
import { MetricCard, DashboardPanel } from '@langlink-tech/antd-kit/dashboard';
import { FormActions } from '@langlink-tech/antd-kit/form';
import { NavigationMenu } from '@langlink-tech/antd-kit/navigation';
import { EmptyState, PageResult } from '@langlink-tech/antd-kit/feedback';

<DataTable rowKey="id" columns={columns} dataSource={rows}
  loading={loading} pagination={pagination} onChange={onChange}
  emptyState={{ description: emptyDescription, action: retryAction }} />
<MetricCard statistic={{ title: metricTitle, value: metricValue }} trend={trend} />
<DashboardPanel title={title} loading={loading} error={error}
  recovery={retryAction} empty={rows.length === 0} emptyDescription={emptyDescription}>
  {chart}
</DashboardPanel>
<NavigationMenu label={navigationLabel} items={items}
  selectedKeys={selectedKeys} onClick={navigate} />
<FormActions submitLabel={saveLabel} submitting={saving} secondary={cancelAction} />
<EmptyState description={emptyDescription} action={retryAction} />
<PageResult status="404" title={missingTitle} extra={homeAction} />
```

`FormDialog` validates an optional host `FormInstance` before invoking `onOk`.
The caller controls `open`, pending state and error handling. Reopening a reused
form store still requires the host to set/reset its fields deliberately; the
shared dialog does not discard business drafts.

`QueryTable` retains the official generic API with a required stable `rowKey`.
It defaults to 25 rows and preserves selection keys across server pages when
selection is enabled. Explicit host pagination/selection options take priority.
Migrations must retain prior page-size and selection policy explicitly where it
differs; do not silently change the user's working context.

```tsx
import { QueryTable } from '@langlink-tech/antd-kit/pro-table';
import { AnalysisSheet } from '@langlink-tech/antd-kit/s2';

<QueryTable rowKey="id" columns={columns} request={request}
  pagination={pagination} rowSelection={rowSelection} />
<AnalysisSheet label={analysisLabel} dataCfg={dataCfg} options={options}
  themeCfg={themeCfg} configure={configureSheet} onError={handleError}
  accessibleFallback={accessibleDataTable} />
```

Memoize `dataCfg`, `options`, `themeCfg` and callbacks: changing them deliberately
recreates the sheet. `configure` connects host drill-down/selection events before
first render. Accessible equivalent content is required because canvas is not an
HTML data table. Resize work is serialized; unmount disconnects observers and
destroys the sheet. S2 never enters the other entry points.

Verified dependency contract: React 19, AntD 6.6.2, optional ProComponents
3.1.14-6 and S2 2.7.2 (existing fleet pins). An AntD 5 / React 18 host must migrate
and verify first; this release does not widen peer support by assumption.

## Candidate consumption and rollback

Until this PR is merged and 0.4.0 is published, test consumers against the exact
`pnpm pack` tarball from the reviewed source commit. Record its SHA-256 in each
consumer PR and commit the lockfile. Do not claim registry publication for a
candidate. Roll back package artifact, lockfile and adopted callers together to
the prior known-good revision.

Node 22 and Node 24 are verified host runtimes. Navigation `landmarkProps` preserves host landmark layout attributes while the menu props remain separate.

## Package access and release boundaries

Package access is an explicit onboarding operation by a package administrator,
using **Package settings → Manage Actions access → Add repository → Read**.
See [GitHub package access documentation](https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility#ensuring-workflow-access-to-your-package).
The release workflow does not mutate organization or consumer permissions.
The previous `grant-package-access` job failed at package lookup with the release
repository's token; a publisher token is not proof of consumer access.

Every new consumer must pass its own cold-store consume smoke with its own
`GITHUB_TOKEN` and `packages: read` before adoption. A library-side smoke cannot
satisfy this gate. Existing consumer smoke workflows remain the access gate;
this separation neither grants broader permissions nor ignores an install failure.
Write registry credentials only to a trusted user npm config in the ephemeral
runner; project config contains only the scope registry route. Never print tokens.

`consume-smoke` verifies published ESM import and clean uninstall. Uninstall is
not a rollback test. Product rollback restores the previous known-good dependency,
lockfile and adapter code, then runs that product's checks and rebuilds. Record
that evidence in the [initiative ledger](https://github.com/langlink-localization/dotfiles/blob/master/specs/antd-shared-component-library-2026-09/initiative-ledger.yaml)
before accepting the rollout. Keep older artifacts available; never overwrite a
published version. This CI repair does not change package source or require a new
package version.

## Versioned releases

Use `pnpm changeset` for releasable changes. In a release PR, run
`pnpm version:packages`, refresh the lockfile, and review the generated version
and changelog. Breaking changes require the affected-consumer list and migration
instructions in that PR. Documentation and CI-only fixes need no package bump.

`pnpm verify` checks Changesets configuration, source behavior and the built pack.
After the reviewed release PR merges, CI builds and publishes the exact manifest
version, confirms registry metadata, then installs it in a cold store. The existing
publish step never overwrites a published version. If the version is already on
the registry, CI compares a stable exports/types/provenance fingerprint and
fails when the contents differ; identical content may rerun. No automation
creates commits or merges release PRs. See the [Changesets guide](https://changesets.dev/guide/getting-started).

Dependency resolution enforces a seven-day minimum release age. Changesets 3.0.2
was published on 2026-09-04 and met that gate before adoption on 2026-09-12.

## HIG-informed overlay behavior (0.5)

- `useDestructiveConfirm({ title, actionLabel, ... })` is for uncommon, irreversible destruction.
  The button carries a specific verb (`"Delete 3 files"`, never a bare OK), uses the danger style,
  and initial focus lands on Cancel so Enter never confirms by default. Common, undoable deletes
  offer undo instead of a confirmation (Apple HIG Alerts; contract RP-03).
- `FormDrawer discardConfirm={{ title, discardText, keepText }}` asks before Escape, mask, close icon
  or Cancel would drop edits (`form.isFieldsTouched()`). Submit paths are unguarded; business
  revision, drafts and conflicts stay in the host (contract RP-01).
