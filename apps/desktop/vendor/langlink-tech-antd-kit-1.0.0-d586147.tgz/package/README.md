# @langlink-tech/antd-kit

LangLink shared Ant Design patterns. Shared patterns for tables, dashboards, forms, navigation, analysis, state surfaces, overlay shells, and the LangLink theme: one theme factory and one root provider for brand, light and dark, density, the contrast floor and the system display preferences.

The rules of the design system (what the kit owns, what a host may and may not do, how to
register an exception, and the versioning promise from 1.0) are in the
[design charter](docs/charter.md) (Chinese).

## Install

The package is published to GitHub Packages (restricted access). It is the only supported way to
consume the kit: do not vendor a tarball or install from a git reference.

`.npmrc` in the host repository (the scope route only, no token):

```ini
@langlink-tech:registry=https://npm.pkg.github.com
```

```sh
pnpm add @langlink-tech/antd-kit
```

- Locally, authenticate once with a personal token that has `read:packages`, in your user
  `~/.npmrc` (`//npm.pkg.github.com/:_authToken=...`), never in the repository.
- In GitHub Actions, give the job `packages: read` and authenticate the install with the job
  token. The kit's reusable workflows do this themselves. In a host's own workflow, either use
  `actions/setup-node` with `registry-url: https://npm.pkg.github.com` and `scope: "@langlink-tech"`
  and pass `NODE_AUTH_TOKEN: ${{ github.token }}` to the install step, or (pnpm 10 and npm only)
  add `//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}` to the repository `.npmrc`; pnpm 11
  does not expand that placeholder in a project `.npmrc`. The host repository also needs read
  access to the package: **Package settings → Manage Actions access → Add repository → Read**.
- The kit declares only `antd`, `react` and `react-dom` as peer dependencies. An entry that
  needs something else expects it among the host's own dependencies:
  `@ant-design/pro-components` for `/pro-table`, `@antv/s2` for `/s2`, `eslint` for `/eslint`,
  `stylelint` for `/stylelint`, `@playwright/test` and `axe-core` for `/testing`. They are not
  listed as optional peers because GitHub Packages drops `peerDependenciesMeta` from registry
  metadata, and pnpm then installs every "optional" peer as a required one.
- A host with `minimumReleaseAge` in `pnpm-workspace.yaml` lists the kit in
  `minimumReleaseAgeExclude`, so a kit release is installable on the day it is published.

`dist/` is built in CI at publish time and is not in git.

## Reduced motion and system display

`LanglinkThemeProvider` reads the system display preferences and applies them: reduced motion
turns AntD motion off, `prefers-contrast: more` gives functional borders 3:1, reduced transparency
makes translucent surfaces solid and the scrim denser, and a stylesheet restores selection and
value indicators under forced colours. A host renders the provider and does nothing else.

`/motion` is for components that animate on their own:

```tsx
import { useReducedMotion } from "@langlink-tech/antd-kit/motion";

const reduceMotion = useReducedMotion(); // the provider's value; true outside a provider
```

| Export | Use |
| --- | --- |
| `useReducedMotion()` | The value the provider resolved. Read this in components |
| `usePrefersReducedMotion()` | The system preference itself (`true` on the server and without `matchMedia`) |
| `ReducedMotionProvider` | Override the value for a subtree or a test |
| `REDUCED_MOTION_QUERY` | The media query string, for tests that stub `matchMedia` |

Deprecated, kept for hosts that have not adopted the provider yet, removed in 2.0:
`usePrefersContrastMore`, `usePrefersReducedTransparency`, `withSystemDisplayTheme`,
`SystemDisplayStyle` (the provider does all four), and `ReducedMotionContext`,
`getReducedMotionSnapshot`, `getServerReducedMotionSnapshot`, `subscribeReducedMotion` (use the
two hooks).

Proof: `tests/motion.test.tsx` and `tests/rendered/system-display.spec.ts` (Chromium with forced
colours and reduced transparency emulated, against the resolved system colours, with control cases
that show the defects without the stylesheet).

## Contrast floor theme (0.9)

AntD's default text tiers are below WCAG 2.2 AA (4.5:1) in several places: link text is 4.10:1 on
white and 3.55:1 on the dark container, `Typography` secondary text 3.36:1, a success `Tag` 2.21:1.
jsdom axe cannot run `color-contrast`, so these pass component tests and fail in a browser.
`LanglinkThemeProvider` and `createLanglinkTheme` apply the floor. A host that still builds its own
theme wraps the whole config once:

```tsx
import { withContrastFloorTheme } from "@langlink-tech/antd-kit/theme";

const floorTheme = useMemo(() => withContrastFloorTheme(hostTheme), [hostTheme]);
<ConfigProvider theme={floorTheme}>
```

It resolves the host theme (seed, light or dark, compact or not) and, for each text slot below
4.5:1, takes the first AntD step that passes on the container, layout and elevated surfaces; when no
step passes it moves the colour away from the surface until it does. Seeds, surfaces and borders are
untouched. Memoize the call: it resolves the design token.

| Slot | Token | Default seed, light | Default seed, dark |
| --- | --- | --- | --- |
| Link text | `colorLink` (algorithm) | `#1677ff` 4.10 → `#0958d9` 6.16 | `#1668dc` 3.55 → lifted |
| Description, placeholder | `colorTextDescription`, `colorTextPlaceholder` | 45% / 25% → 65% tier | 45% / 25% → 65% tier |
| Status text | `color*Text` (algorithm); `Form`, `Button` `colorError` | error 3.27, success 2.27, warning 1.90 → lifted | error 4.35 → lifted |
| Solid primary fill | `Button`, `Switch`, `FloatButton` `colorPrimary` | `#1677ff` 4.10 → `#0958d9` 6.16 | unchanged (5.19) |
| Switch off track (under `unCheckedChildren`) | `Switch` `colorTextQuaternary`, `colorTextTertiary` | 25% tier, 1.90 → darkened | resting unchanged; hover 4.06 → darkened |
| Tag text | `Tag` `color{Success,Error,Warning,Info}`, `{preset}7` | on each tag's own tint | on each tag's own tint |
| Brand text | `Menu` (selected, hover, open submenu title), `Tabs`, `Pagination` | `#0958d9` | lifted |
| Field labels, empty text | `Descriptions.labelColor`, `Table` string `emptyText` | description tier | description tier |

Tokens the host already sets win, globally and per component, so a registered value keeps working
and the host owns its proof. Visible changes to expect on adoption: placeholders and secondary text
are darker; on dark surfaces a solid danger button keeps a readable red as text and switches its
label to the dark tone, because no red passes both as text on the page and under a white label.

ProComponents draws the query-filter expand/collapse control in `colorPrimary` and has no token for
it. `QueryTable` (`/pro-table`) sets a `collapseRender` that uses the link text colour. A host's own
`collapseRender` wins. The ProLayout menu needs nothing extra: with the floor applied it scans clean,
including an open group with a selected child (`tests/rendered/contrast-pro.spec.ts`).

Not covered, because AntD exposes no token: primary `outlined` / `dashed` / `text` buttons on dark
surfaces (3.55:1), and text at reduced opacity (a loading button). `contrastRatio` and
`ensureContrast` are exported for host tokens and tests. Proof: `tests/theme.test.ts` (WCAG formula
over the resolved tokens, four mode and density combinations, three extra seeds) and
`tests/rendered/contrast-floor.spec.ts` (axe `color-contrast` in Chromium, with a plain-AntD control).

## Theme and root provider (1.0 preparation)

The kit owns the whole theme. A host renders one provider at its root and stops keeping its own
theme file, preference storage, density profile table and `--ll-*` palette:

```tsx
import { LanglinkThemeProvider, useLanglinkTheme } from "@langlink-tech/antd-kit/provider";
import zhCN from "antd/locale/zh_CN";

<LanglinkThemeProvider brand="langlink-blue" storageKey="portal.theme" locale={zhCN}>
  <Shell />
</LanglinkThemeProvider>;

function ThemeSwitch() {
  const { mode, resolvedMode, density, setMode, setDensity } = useLanglinkTheme();
  // mode: "light" | "dark" | "system"; resolvedMode: "light" | "dark"
}
```

`LanglinkThemeProvider` renders AntD `ConfigProvider` and `App`, `SystemDisplayStyle` and the
reduced-motion context, and:

- keeps the mode and density preference in `localStorage` (`storageKey`, default
  `langlink.theme`; `false` keeps it in memory), follows changes from other tabs, and survives
  blocked or full storage;
- follows `prefers-color-scheme` live while the mode is `"system"` (the default);
- reads `prefers-reduced-motion`, `prefers-reduced-transparency` and `prefers-contrast` and applies
  them to the theme;
- writes `color-scheme`, `data-theme`, `data-density` and the `--ll-*` variables on the root, so a
  host's own CSS follows mode, brand and density without a second palette (`rootVariables={false}`
  turns this off);
- sets the root `componentSize` from the density (`medium` or `small`).

| Prop | Default | Meaning |
| --- | --- | --- |
| `brand` | `"langlink-blue"` | A preset name, or `{ colorPrimary }` for a product outside the presets |
| `defaultMode` / `defaultDensity` | `"system"` / `"comfortable"` | Used until the user chooses, and for the first render |
| `mode` / `density` | none | Fixes the value; the stored preference no longer changes what is drawn |
| `storageKey` | `"langlink.theme"` | `localStorage` key; `false` turns persistence off |
| `legacyKeys` | none | The host's previous `{ mode, density }`, as keys or reader functions, migrated once (below) |
| `cookieName` / `initialTheme` | none | Mirror the drawn theme to a cookie, and start a server render from it (below) |
| `rootElement` | the document root | An element or ShadowRoot that receives the variables and attributes (below) |
| `theme` | none | Host `ThemeConfig` merged over the kit's. Keep the reference stable |
| `antdApp` | `{}` | Props for AntD `App`; `false` when the host renders its own |
| other `ConfigProvider` props | | `locale`, `direction`, `getPopupContainer`, ... pass through |

Migrating a stored preference: a host that kept mode and density under its own keys passes them
as `legacyKeys`. On the first mount where `storageKey` holds nothing, the provider reads the old
keys, applies what they hold, and writes it under `storageKey`. It happens once; the old keys are
not deleted, so rolling the host back still finds them. Values must be the plain strings `light` /
`dark` / `system` and `comfortable` / `compact`; anything else is ignored. Keep the object stable
(a module constant).

A host that kept the value inside something else passes a reader function instead of a key. It
receives `localStorage` and returns the value, or `undefined`; a reader that throws is ignored.
Keys and readers can be mixed in an array and are tried in order.

```tsx
// plunet-api-server: zustand persist blob under "ui-preferences"
const fromZustand = (field: string) => (storage: Storage) =>
  JSON.parse(storage.getItem("ui-preferences") ?? "{}").state?.[field];
const LEGACY_KEYS = { mode: fromZustand("themeMode"), density: fromZustand("density") };
```

```tsx
const LEGACY_KEYS = { mode: "portal.theme.mode", density: "portal.density.profile" };
<LanglinkThemeProvider storageKey="portal.theme" legacyKeys={LEGACY_KEYS}>
```

| Host | `mode` key | `density` key |
| --- | --- | --- |
| langlink-tech-portal | `portal.theme.mode` | `portal.density.profile` |
| public-mailbox-feishu-cloudflare | `public-mailbox.theme.mode` | `public-mailbox.density.profile` |
| internal-release-hub-cloudflare | `release-hub.theme.mode` | `release-hub.density.profile` |
| secure-files-cloudflare | `secure-files.theme.mode` | `secure-files.density.profile` |
| langlink-lqa-tapd | `langlink.uiTheme` | `langlink.uiDensity` |
| langlink-tools | `langlink-theme-mode` | `langlink-density-profile` |

plunet-api-server keeps both values in the zustand blob `ui-preferences` (use a reader, above).
plunet-chrome-plugin, langlink-toolbox and langlink-work-agent keep no `localStorage` value for
either, so they have nothing to migrate.

Server rendering: without a cookie, the first render (on the server and during hydration) uses the
defaults and the server fallbacks of the system preferences (light, motion off). The stored
preference and the system colour scheme apply right after hydration, without a hydration mismatch,
so a dark-mode user sees one light frame.

`cookieName` removes that frame. The provider writes what it draws to the cookie
(`mode:resolvedMode:density`, for example `system:dark:compact`; `path=/`, one year, `SameSite=Lax`,
`Secure` on https). The server reads it with `readThemeCookie` from `/server`, which is not a client
module, and passes the result as `initialTheme`. The server render and hydration then start from
the cookie; what the browser has stored still wins after hydration.

```tsx
// app/layout.tsx (Next.js Server Component)
import { headers } from "next/headers";
import { readThemeCookie } from "@langlink-tech/antd-kit/server";

const initialTheme = readThemeCookie((await headers()).get("cookie"));
return <Providers initialTheme={initialTheme}>{children}</Providers>;

// providers.tsx ("use client")
<LanglinkThemeProvider cookieName="langlink.theme" initialTheme={initialTheme}>
```

Shadow DOM and embedded UI: `rootElement` is where the `--ll-*` variables, `color-scheme`,
`data-theme` and `data-density` go instead of the document root. For a ShadowRoot the variables
are a `:host` rule in a style element inside it and the attributes go on the host; for an element
they are inline custom properties. A function is called after mount, for a root that does not
exist at render time. The page around the UI is left untouched, and everything is undone on
unmount. A content script usually also sets `storageKey={false}` (the page's `localStorage` belongs
to the page) and `getPopupContainer`.

```tsx
const shadow = host.attachShadow({ mode: "open" });
createRoot(mount).render(
  <LanglinkThemeProvider rootElement={shadow} storageKey={false} getPopupContainer={() => mount}>
    <Panel />
  </LanglinkThemeProvider>,
);
```

### `createLanglinkTheme`

The pure function behind the provider, for tests, Storybook-like harnesses and hosts that cannot
use the provider:

```ts
import { createLanglinkTheme } from "@langlink-tech/antd-kit/theme";

const theme = createLanglinkTheme({
  brand: "plunet-teal", // "langlink-blue" (#1677ff, default) | "memoq" (#0066ff) | "plunet-teal" (#0f766e)
  mode: "system", // "light" | "dark" | "system"
  systemDark, // what the system says; only read for "system"
  density: "compact", // "comfortable" | "compact"
  display: { reduceMotion, reduceTransparency, contrastMore },
  overrides: { components: { Layout: { headerHeight: 56 } } },
});
```

It applies, in this order: the brand and status seeds and the radius seed; `darkAlgorithm` for dark;
`compactAlgorithm` for compact, with small controls pinned to 24px (WCAG 2.5.8 target size;
`compactAlgorithm` alone gives 21px) and large controls to 40px (35px otherwise);
`withContrastFloorTheme`; then `prefers-contrast: more`, reduced transparency and `motion: false`
for reduced motion. `overrides.token` wins key by key and over the floor, `overrides.components`
merge per component, `overrides.algorithm` runs after the mode and density algorithms.

`langlinkCssVariables(theme, density)` returns the `--ll-*` map the provider writes:
`--ll-color-primary`, `-link`, `-text`, `-text-secondary`, `-text-muted`, `-bg-page`,
`-bg-container`, `-bg-elevated`, `-border`, `-border-subtle`, `-success`, `-warning`, `-error`,
`--ll-radius-sm|md|lg`, `--ll-font-family`, `--ll-density-page-padding` (24 / 16px) and
`--ll-density-section-gap` (24 / 12px).

Proof: `tests/theme.test.ts` (`createLanglinkTheme`: three brands in light and dark, comfortable and
compact, on the contrast floor; control heights; system preferences), `tests/provider.test.tsx`
(persistence, storage key, cross-tab change, system dark, server render and hydration, legacy
readers, the theme cookie and `initialTheme`, `rootElement` on an element and a ShadowRoot) and the
`provider` cases in `tests/rendered/contrast-floor.spec.ts` (axe `color-contrast` and measured
24 / 32 / 40px control heights in Chromium).

## Icons (1.0 preparation)

Hosts import icons from the kit, by meaning, and no longer depend on `@ant-design/icons`,
`lucide-react` or `@mui/icons-material`. The glyphs are [lucide](https://lucide.dev), a dependency
of the kit.

```tsx
import { DeleteIcon, RefreshIcon, StarIcon } from "@langlink-tech/antd-kit/icons";

<Button icon={<RefreshIcon />}>Refresh</Button>
<Button icon={<DeleteIcon />} aria-label="Delete template" danger />
<StarIcon filled aria-label="Starred" />
```

- Each icon is `span.anticon[role="img"]` around a `1em` SVG that draws in `currentColor` with one
  stroke width (`ICON_STROKE_WIDTH`, 1.75). That is the wrapper AntD puts around its own icons, so
  the icon takes AntD's size, baseline and spacing in Button, Menu, Tabs and every other `icon` slot.
- Accessible name: an icon with `aria-label` (or `aria-labelledby`) is an image with that name. An
  icon without one is decoration and hidden from assistive technology. An icon-only control therefore
  needs a name on the control (`<Button aria-label>`) or on the icon; the kit's ESLint config checks
  icon-only `Button`s.
- Props: any `span` attribute, plus `filled` (solid shape for an "on" state such as a starred row),
  `spin` (on by default for `LoadingIcon`) and `strokeWidth`.
- `CustomIcon` wraps a host's own SVG (a product logo) in the same shell.

Names say what the icon means. Several AntD glyphs that meant the same thing are one icon:
`ReloadOutlined`, `SyncOutlined` and `RedoOutlined` are `RefreshIcon`; `WarningOutlined` and both
`ExclamationCircle` variants are `WarningIcon`; `EditOutlined` and `FormOutlined` are `EditIcon`;
`Outlined` / `Filled` pairs are one icon with `filled`. `docs/icon-map.json` lists all 147 AntD names
the hosts import today and the kit icon for each (129 kit icons).

### Icons inside AntD components

`LanglinkThemeProvider` replaces the icons AntD draws itself, through the component config of AntD
6.6.5 (`kitIcons={false}` turns it off, and a host config key wins over the kit's for that key):

| Components | Icons |
| --- | --- |
| Modal, Drawer, Alert, Notification, Tour, Image preview, FloatButton.Group | close |
| Modal and Alert | success, info, warning, error |
| Select, Cascader | arrow, clear, remove, selected item, loading; Cascader expand and search |
| DatePicker, TimePicker, RangePicker | calendar and clock, clear, range separator |
| Input.Search, Input.Password | search; show and hide |
| Collapse, Menu, TreeSelect | expand arrow, tree switcher |
| Tabs, Breadcrumb, Transfer | more, add, remove; dropdown arrow |
| Button, FloatButton | loading; back to top |

AntD 6.6.5 has no config for these, so they keep AntD's glyphs: the TreeSelect arrow, message and
notification status icons, Result, Popconfirm, Form feedback, Steps, Tree, Table sort and filter
controls, Pagination arrows, the date panel's header arrows, Upload, Rate and Input's `allowClear`.

Two icons AntD can configure are not set globally, because a global value changes components that
do not show the icon:

- Tag close icon: AntD reads a configured close icon as "tags are closable", so every Tag would get
  a close button. Pass `closeIcon={<CloseIcon />}` on a closable Tag.
- Table expand icon: AntD then reserves the expand cell in every table, expandable or not, which
  indents the first column. `DataTable` (`/table`) applies the kit's expand control, a chevron in
  a labelled 24px button (`TableExpandIcon`), when it is given `expandable`.

Accessible names: AntD's own icons carry an `aria-label`, which is what names the controls that
hold nothing but an icon. The kit names its replacements where that is the case: the Tabs overflow
button ("More tabs"), the Input.Search button ("Search"), the Input.Password toggle ("Show
password" / "Hide password"), the Alert close button and picker clear buttons ("Close", "Clear"),
and FloatButton.BackTop ("Back to top"). A host with another interface language passes its own
icon with a translated `aria-label` through the matching provider prop (`tabs={{ moreIcon }}`).

### Migrating a host

```sh
node path/to/antd-kit/scripts/codemod-icons.mjs src           # report
node path/to/antd-kit/scripts/codemod-icons.mjs --write src   # rewrite
```

The codemod rewrites `@ant-design/icons` imports (named and deep) and `lucide-react` imports, every
reference, and adds `filled` for the Filled variants. `docs/icon-map.json` has one section per
source package. It does not rewrite a file where a person has to decide, and lists the reason: a
name missing from the map, AntD's `Icon` component (use `CustomIcon`), a namespace or default
import, a prop a kit icon does not take (AntD's `rotate`, `twoToneColor`, `component`; lucide's
`size`, `color`, `absoluteStrokeWidth`: a kit icon is sized by `font-size` and coloured by `color`
in CSS), a lucide type import, a Filled icon passed as a component reference, or a kit name the
file already declares. Selectors in host tests that name
AntD icon classes (`.anticon-reload`) change to the kit class (`.anticon-refresh`).

Proof: `tests/icons.test.tsx` (wrapper, naming, the map, the provider config, the codemod) and
`tests/rendered/icons.spec.ts` (Chromium: a kit icon and the AntD icon it replaces have the same box
in Button, icon-only Button, small Button, Menu item and Tab, in light and dark; Select arrow
position; inline submenu arrows; the table expand button; screenshots attached to the report).

## Brand palette (0.11)

`brandThemeConfig` and `brandTokens` remain for hosts that have not adopted the provider. A new
host uses `LanglinkThemeProvider` with a brand preset instead.

Four hosts repeated the same seeds, radius and solid-fill overrides in their own theme files. The
`/theme` entry now carries them once:

```tsx
import { brandThemeConfig } from "@langlink-tech/antd-kit/theme";
import { theme } from "antd";

const hostTheme = useMemo(
  () =>
    brandThemeConfig(mode, {
      // Optional. Every key is a normal AntD theme config key.
      algorithm: compact ? theme.compactAlgorithm : undefined,
      token: { motion: !reduceMotion, ...(compact ? { controlHeightSM: 24 } : {}) },
      components: { Layout: { headerHeight: 56 } },
    }),
  [mode, compact, reduceMotion],
);
<ConfigProvider theme={hostTheme}>
```

- `brandThemeConfig(mode = "light", overrides = {})` returns a `ThemeConfig` that has already been
  through `withContrastFloorTheme`; do not wrap it again. It sets `colorPrimary` `#1677ff`,
  `colorSuccess` `#52c41a`, `colorWarning` `#faad14`, `colorError` `#ff4d4f` and `borderRadius` 6, and
  uses AntD's `darkAlgorithm` for `"dark"`.
- `overrides.token` wins key by key, so a host with its own brand keeps it:
  `brandThemeConfig(mode, { token: { colorPrimary: "#0066ff" } })`. `overrides.algorithm` runs after
  the mode algorithm. `overrides.components` and any other key (`cssVar`, `hashed`) pass through,
  and host tokens win over the floor as before.
- `brandTokens` also holds `text.primary`, `surface`, `border.default`, `spacing` and
  `typography.family`. `brandThemeConfig` does not put those into the AntD theme: they are the light
  values for a host's own CSS variables. In dark, read the resolved AntD token
  (`theme.getDesignToken(brandThemeConfig("dark"))`) instead of adding a second palette. The
  `radius` and `spacing` ladders equal what AntD derives from `borderRadius` 6 and its size seed.

Delete the hand-written `Button` / `Switch` / `FloatButton` `colorPrimary: "#0958d9"` overrides when
adopting; the floor resolves the fill from the seed in use.

| Seed | Mode | Resting fill, white label | Hover and pressed |
| --- | --- | --- | --- |
| `#1677ff` (brand) | light | `#0958d9` 6.16, same as the hand-written value | `#0746ae` 8.41 (hand-written `#003eb3` was 8.97) |
| `#1677ff` (brand) | dark | `#1668dc` 5.19, AntD's dark primary | `#1253b0` 7.27 |
| `#0066ff` (host override) | light | `#0066ff` 4.83 | `#0052cc` 6.82 |
| `#0066ff` (host override) | dark | `#035adc` 6.00 | `#0248b0` 8.21 |
| `#0f766e` (host override) | light | `#0f766e` 5.47 | `#0c5e58` 7.62 |
| `#0f766e` (host override) | dark | `#106761` 6.70 | `#0d524e` 9.00 |

Visible change for a host that drops its overrides: the hover and pressed fill in light is one step
lighter than `#003eb3`, and the dark fill is AntD's dark primary `#1668dc` instead of `#0958d9`, the
same colour as checkboxes and other primary surfaces. Status text is unchanged in both modes. Proof:
`tests/theme.test.ts` (`brandThemeConfig`) and the `brand palette` cases in
`tests/rendered/contrast-floor.spec.ts`.

## Lint, test helpers and CI (1.0 preparation)

The kit ships the gates that hosts used to copy as scanner scripts and regular expressions.
`eslint`, `stylelint`, `@playwright/test` and `axe-core` are not dependencies of the kit: a host
installs the ones whose entry it uses.

### ESLint: `@langlink-tech/antd-kit/eslint`

```js
// eslint.config.js (flat config). The host supplies its own parser and base configs.
import langlink from "@langlink-tech/antd-kit/eslint";

export default [...hostConfigs, ...langlink.configs.recommended];
```

| Rule | Reports |
| --- | --- |
| `langlink/no-static-modal` | `Modal.confirm()` and the other static methods (`info`, `success`, `error`, `warning`): they render outside `ConfigProvider`. Use `useAppConfirm()` / `useDestructiveConfirm()` |
| `langlink/no-wrapped-antd-import` | Importing from `antd` a component the kit wraps: `Empty`, `Spin`, `Result`, `Popconfirm`, `Table`, `Modal` (type imports are fine) |
| `langlink/no-icon-package` | Any import of `@ant-design/icons`, `lucide-react` or `@mui/icons-material`; icons come from the kit |
| `langlink/no-color-literal` | Hex and `rgb()` / `hsl()` colour literals outside theme files and tests |
| `langlink/icon-button-label` | An icon-only `<Button>` without `aria-label`, `aria-labelledby` or `title` |

`createConfig({ files, wrappedComponents, iconPackages, colorLiteralFiles })` builds the same config
with a host's file globs, its own component map, or extra files where colour literals are allowed.

#### Adopting on an existing codebase: the suppressions ratchet

Do not turn rules off or scatter `eslint-disable` comments to get to green. Record today's
violations once, and let the file only shrink:

```sh
pnpm exec eslint . --suppress-all      # writes eslint-suppressions.json; commit it
pnpm exec eslint .                     # CI: fails on any violation that is not recorded
pnpm exec eslint . --prune-suppressions   # after fixing some: drops the entries no longer needed
```

- The file counts violations per rule and file. A new violation in a file fails; an existing one
  does not. ESLint also fails when a recorded violation is gone but still listed, so the count
  cannot drift upward under a fixed one: prune and commit.
- Review rule: a pull request may delete lines from `eslint-suppressions.json`, never add them.
  Adding one is a registered exception and needs its reason in the pull request.
- Stylelint 17 has the same mechanism: `stylelint "**/*.css" --suppress` writes
  `stylelint-suppressions.json`.

### Stylelint: `@langlink-tech/antd-kit/stylelint`

```js
// stylelint.config.js
import { createConfig } from "@langlink-tech/antd-kit/stylelint";

export default createConfig({
  allowedAntSelectors: ["ant-pro-sider-menu"], // registered exceptions, each with its reason
  allowedDurations: ["1s"],
});
```

It uses core rules only: no selector may name an AntD class (`.ant-*`, `.ant-pro-*`; style AntD
through tokens and the `classNames` / `styles` props), no hex colours (`color-no-hex`), and no
literal duration in `transition` / `animation` (use `var(--ant-motion-duration-mid)` or a host
motion variable; zero is allowed). The default export is the config without exceptions.

### Playwright helpers: `@langlink-tech/antd-kit/testing`

| Helper | Use |
| --- | --- |
| `expectContrastFloor(page, testInfo?)` | axe `color-contrast` on the state on screen; fails on a violation and on a scan that measured no text; attaches the report |
| `defineContrastSweep(test, { routes, modes, densities, storageKey, prepare, ready })` | One contrast test per route, mode and density, without screenshots |
| `expectNoAxeViolations(page, testInfo?, { tags, disableRules })` | Full axe scan, WCAG 2.0 to 2.2 A and AA by default |
| `expectFunctionalBorderContrast(page)` / `measureFunctionalBorders` | AntD `colorBorder` surfaces reach 3:1 (for `prefers-contrast: more`) |
| `prepareStablePage(page, { time })`, `disableTransitions`, `settlePage` | Reduced motion, no transitions, fixed date; wait for loading indicators and fonts |
| `setThemePreference(page, { mode, density }, storageKey?)` | Store the `LanglinkThemeProvider` preference before the app loads |
| `expectStableScreenshot(page, name)` | `toHaveScreenshot` after settling, animations and caret off |

```ts
import { test } from "@playwright/test";
import { defineContrastSweep } from "@langlink-tech/antd-kit/testing";

defineContrastSweep(test, {
  routes: ["/mailboxes", "/rules", "/admin/users"],
  storageKey: "mailbox.theme",
  prepare: (page) => routeFixtures(page),
  ready: (page, { route }) => expect(page).toHaveURL(new RegExp(`${route.path}$`)),
});
```

### Reusable workflows

Hosts call these with `uses: langlink-tech/antd-kit/.github/workflows/<file>@<full commit SHA>`.
Each installs the tools from the host's `.mise.toml`, runs the host's install command and then the
host's command. Example callers are in the header of each file.

| Workflow | Runs | When |
| --- | --- | --- |
| `reusable-lint.yml` | ESLint and Stylelint commands | Every pull request |
| `reusable-axe.yml` | The host's axe and contrast specs in Chromium; uploads the report on failure | Every pull request |
| `reusable-visual.yml` | The host's screenshot specs; uploads diffs on failure | Only when the pull request changes UI files (`ui-paths`) or has the `visual` label; other events always run |

Each workflow writes its own npm authentication for GitHub Packages from the job token (input
`registry-scope`, default `@langlink-tech`), so a host needs `packages: read` on the calling job
and no token line in its `.npmrc`. `reusable-visual.yml` takes `container-image` (and
`container-options`, default `--ipc=host`) for hosts whose baselines are made in a pinned Playwright
image; without it the job runs on the runner.

`reusable-visual.yml` decides in a first job from the pull request's file list (it needs
`pull-requests: read`; if the list cannot be read, the screenshots run). When it decides to skip,
the screenshot job is skipped, which a required check counts as passing.

Proof: `tests/eslint.test.ts` and `tests/stylelint.test.ts` (each rule on passing and failing
sources, with the real linters), `tests/rendered/testing.spec.ts` (the helpers pass on the kit's
contrast harness and fail on plain AntD), `actionlint` on the workflows.

## Governed component patterns (0.4)

The entries are additive patterns, not renamed upstream exports. Host
providers, data requests, validation, permissions, selection and routing remain
in the application. Import only the entry needed by a page. ProTable and S2 come from the
host's own dependencies; importing the other entries does not load either engine.

| Entry | Exports | Official API / example reference |
| --- | --- | --- |
| `/table` | `DataTable` | [Table empty, loading and row selection](https://ant.design/components/table/) |
| `/pro-table` | `QueryTable` | [ProTable](https://procomponents.ant.design/components/table), Pro `list/table-list` |
| `/dashboard` | `MetricCard`, `DashboardPanel` | [Pro analysis dashboard](https://github.com/ant-design/ant-design-pro/tree/master/src/pages/dashboard/analysis) |
| `/form` | `FormDialog`, `FormActions` | [Form in Modal](https://ant.design/components/form/) |
| `/navigation` | `NavigationMenu` | [Controlled Menu](https://ant.design/components/menu/), named navigation landmark |
| `/s2` | `AnalysisSheet` | [S2 pivot example](https://s2.antv.antgroup.com/examples/basic/pivot), render/destroy/resize lifecycle |
| `/feedback` | `EmptyState`, `ContentLoading`, `PageResult` | [Empty](https://ant.design/components/empty/), [Skeleton](https://ant.design/components/skeleton/), [Spin](https://ant.design/components/spin/), [Result](https://ant.design/components/result/) |
| `/overlay` | `FormDrawer`, `PreviewDialog`, `ConfirmAction`, `useAppConfirm`, `useDestructiveConfirm` | [Form in Drawer](https://ant.design/components/form/), [Modal](https://ant.design/components/modal/), [Popconfirm](https://ant.design/components/popconfirm/), [App](https://ant.design/components/app/) |

Library entries are client modules. Packed `dist/*.js` files keep a `"use client"`
directive so a Next.js Server Component can import `EmptyState` without turning
the whole page into a client shell. Optional Pro/S2 peers stay out of core
entries.

### Wrapper value

| Export | Decision | Shared behavior | Native allowed |
| --- | --- | --- | --- |
| `EmptyState` | keep | required `description`, optional `action` | native Empty only when there is no next-action contract |
| `PageResult` | keep | page-level Result; `extra` stays host-owned | native Result or Alert for inline recovery |
| `ConfirmAction` | keep | in-place Popconfirm; shared inflight promise (success closes, async reject and sync throw stay open and clear pending) | `useAppConfirm()` for high-risk/irreversible |
| `MetricCard` | keep | Statistic in a Card plus optional `trend` | native `Statistic` when Card chrome is wrong |

Do not remove these exports in 0.4. Return the `onConfirm` promise so rejection
stays a rejection. `void onConfirm()` at a call site drops that signal.

#### Consumer props map (read-only; this PR does not edit hosts)

| Export | Host path | Props actually passed |
| --- | --- | --- |
| `EmptyState` | `ll-lqa-test/src/pages/admin/AdminTestsPage.tsx` | `description`, `action` (create button) |
| `EmptyState` | `ll-lqa-test/src/pages/admin/AdminPeoplePage.tsx` | `description` only on no-matches |
| `EmptyState` | `secure-files-cloudflare/src/frontend/App.tsx` | `description`; table `emptyText` slot |
| `EmptyState` | `langlink-tech-portal/frontend/src/pages/ToolsPage.tsx` | empty/filter empty copy |
| `PageResult` | `ll-lqa-test/src/pages/NotFoundPage.tsx` | `status="404"`, `title`, `subTitle`, `extra` (back button) |
| `PageResult` | `langlink-tech-portal/frontend/src/App.tsx` | `status="404"`, `title`, `subTitle`, `extra` |
| `PageResult` | `antd-pro-clone/src/pages/exception/404/index.tsx` | imported as `Result`; `status`, `title`, `subTitle`, `extra` |
| `ConfirmAction` | `ll-lqa-test/src/pages/admin/AdminTestsPage.tsx` | `title`, `description`, `okText`, `cancelText`, `okButtonProps.danger`, `onConfirm` |
| `ConfirmAction` | `secure-files-cloudflare/src/frontend/App.tsx` | `title` (JSX), `onConfirm` wrapping delete |
| `ConfirmAction` | `secure-files-cloudflare/src/frontend/operations/OperationsPanel.tsx` | `title`, `onConfirm` retry/replay |
| `MetricCard` | `ll-lqa-test/src/pages/admin/AdminDashboardPage.tsx` | `statistic={{ title, value }}` |
| `MetricCard` | `langlink-tech-portal/frontend/src/pages/HomePage.tsx` | `variant="borderless"`, `styles.body.padding: 0`, `statistic` |
| `MetricCard` | `antd-pro-clone/src/pages/dashboard/workplace/index.tsx` | same borderless/zero-padding Statistic chrome |
| `MetricCard` | `plunet-chrome-plugin/src/sidepanel/components/OrderHealthPanel.tsx` | borderless Statistic counts |

Hosts that pass `variant="borderless"` and zero padding are the documented
Statistic carve-out: they may keep MetricCard or switch to native Statistic
without a library removal.

```tsx
import { DataTable } from '@langlink-tech/antd-kit/table';
import { MetricCard, DashboardPanel } from '@langlink-tech/antd-kit/dashboard';
import { FormActions } from '@langlink-tech/antd-kit/form';
import { NavigationMenu } from '@langlink-tech/antd-kit/navigation';
import { EmptyState, PageResult } from '@langlink-tech/antd-kit/feedback';

<DataTable rowKey="id" columns={columns} dataSource={rows}
  loading={loading} pagination={pagination} onChange={onChange}
  emptyState={{ description: emptyDescription, action: retryAction }} />
<MetricCard statistic={{ title: metricTitle, value: metricValue }} trend={trend} />
<DashboardPanel title={title} loading={loading} error={error}
  recovery={retryAction} empty={rows.length === 0} emptyDescription={emptyDescription}>
  {chart}
</DashboardPanel>
<NavigationMenu label={navigationLabel} items={items}
  selectedKeys={selectedKeys} onClick={navigate} />
<FormActions submitLabel={saveLabel} submitting={saving} secondary={cancelAction} />
<EmptyState description={emptyDescription} action={retryAction} />
<PageResult status="404" title={missingTitle} extra={homeAction} />
```

`FormDialog` validates an optional host `FormInstance` before invoking `onOk`.
The caller controls `open`, pending state and error handling. Reopening a reused
form store still requires the host to set/reset its fields deliberately; the
shared dialog does not discard business drafts.

`QueryTable` retains the official generic API with a required stable `rowKey`.
It defaults to 25 rows and preserves selection keys across server pages when
selection is enabled. Explicit host pagination/selection options take priority.
Migrations must retain prior page-size and selection policy explicitly where it
differs; do not silently change the user's working context.

```tsx
import { QueryTable } from '@langlink-tech/antd-kit/pro-table';
import { AnalysisSheet } from '@langlink-tech/antd-kit/s2';

<QueryTable rowKey="id" columns={columns} request={request}
  pagination={pagination} rowSelection={rowSelection} />
<AnalysisSheet label={analysisLabel} dataCfg={dataCfg} options={options}
  themeCfg={themeCfg} configure={configureSheet} onError={handleError}
  accessibleFallback={accessibleDataTable} />
```

Memoize `dataCfg`, `options`, `themeCfg` and callbacks: changing them deliberately
recreates the sheet. `configure` connects host drill-down/selection events before
first render. Accessible equivalent content is required because canvas is not an
HTML data table. Resize work is serialized; unmount disconnects observers and
destroys the sheet. S2 never enters the other entry points.

Verified dependency contract: React 19, AntD 6.6.5, optional ProComponents
3.1.14-6 and S2 2.7.2 (existing fleet pins). An AntD 5 / React 18 host must migrate
and verify first; this release does not widen peer support by assumption.

## Rollback

A host rolls back by restoring its previous `@langlink-tech/antd-kit` version and lockfile together
with the code that adopted the newer one, then running its own checks. Published versions are never
overwritten, so the earlier version stays installable.

Node 22 and Node 24 are verified host runtimes. Navigation `landmarkProps` preserves host landmark layout attributes while the menu props remain separate.

## Package access and release boundaries

Package access is an explicit onboarding operation by a package administrator,
using **Package settings → Manage Actions access → Add repository → Read**.
See [GitHub package access documentation](https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility#ensuring-workflow-access-to-your-package).
The release workflow does not mutate organization or consumer permissions.
The previous `grant-package-access` job failed at package lookup with the release
repository's token; a publisher token is not proof of consumer access.

Every new consumer must pass its own cold-store consume smoke with its own
`GITHUB_TOKEN` and `packages: read` before adoption. A library-side smoke cannot
satisfy this gate. Existing consumer smoke workflows remain the access gate;
this separation neither grants broader permissions nor ignores an install failure.
Write registry credentials only to a trusted user npm config in the ephemeral
runner; project config contains only the scope registry route. Never print tokens.

`consume-smoke` verifies published ESM import and clean uninstall. Uninstall is
not a rollback test. Product rollback restores the previous known-good dependency,
lockfile and adapter code, then runs that product's checks and rebuilds. Record
that evidence in the [initiative ledger](https://github.com/langlink-localization/dotfiles/blob/master/specs/antd-shared-component-library-2026-09/initiative-ledger.yaml)
before accepting the rollout. Keep older artifacts available; never overwrite a
published version. This CI repair does not change package source or require a new
package version.

## Versioned releases

From 1.0 the kit follows semver; the promise to hosts (patch on demand, a monthly minor, majors
only with a migration path, kit and antd upgraded together) is in the
[design charter](docs/charter.md).

Use `pnpm changeset` for releasable changes. In a release PR, run
`pnpm version:packages`, refresh the lockfile, and review the generated version
and changelog. Breaking changes require the affected-consumer list and migration
instructions in that PR. Documentation and CI-only fixes need no package bump.

`pnpm verify` checks Changesets configuration, source behavior and the built pack.
After the reviewed release PR merges, CI builds and publishes the exact manifest
version, confirms registry metadata, then installs it in a cold store. The existing
publish step never overwrites a published version. If the version is already on
the registry, CI compares a stable exports/types/provenance fingerprint and
fails when the contents differ; identical content may rerun. No automation
creates commits or merges release PRs. See the [Changesets guide](https://changesets.dev/guide/getting-started).

Dependency resolution enforces a seven-day minimum release age. Changesets 3.0.2
was published on 2026-09-04 and met that gate before adoption on 2026-09-12.

## HIG-informed overlay behavior (0.5)

- `useDestructiveConfirm({ title, actionLabel, ... })` is for uncommon, irreversible destruction.
  The button carries a specific verb (`"Delete 3 files"`, never a bare OK), uses the danger style,
  and initial focus lands on Cancel so Enter never confirms by default. Common, undoable deletes
  offer undo instead of a confirmation (Apple HIG Alerts; contract RP-03).
- `FormDrawer discardConfirm={{ title, discardText, keepText }}` asks before Escape, mask, close icon
  or Cancel would drop edits (`form.isFieldsTouched()`). Submit paths are unguarded; business
  revision, drafts and conflicts stay in the host (contract RP-01).
